/*
** Print from A to Z
**
*/
#include <stdio.h>

int main()
{
    char ch;

    for (ch = 'A'; ch <= 'Z'; ch++)
    {
        putchar(ch);
    }

    return 0;
}
