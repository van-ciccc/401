#include <stdio.h>

int Add(int a, int b)
{
    return a + b;
}

void printHello()
{
    printf("Hello\n");
}

int main()
{
    /* create a function pointer(ptr) to printHello */
    void (*ptr)();
    ptr = printHello;
    ptr();

    int c;
    int (*p)(int, int);
    p = Add; // the function name will return a pointer.

    (*p)(2, 3);  // de-referencing and executing the function.
    c = p(2, 3); // Add(2, 3);
    printf("c = %d\n", c);

    return 0;
}

void any(int a)
{
    putchar(a);
}

void vc_foreach(int *tab, int length, void (*f)(int))
{
    f(10);
}
int main()
{
    int arr[5] = {1, 2, 3, 4, 5};
    void (*p)(int);
    p = any;
    vc_foreach(arr, 5, p);
    return 0;
}
