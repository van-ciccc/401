/**
 * File              : sllist.c
 * Author            : Derrick Park
 * Date              : Wed  8 Aug 10:46:39 2018
 * Last Modified Date: Wed  8 Aug 10:46:39 2018
 * Last Modified By  : Derrick Park
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct sllist
{
    int val;
    struct sllist *next;
} sllnode;

sllnode *create(int val)
{
    // Dynamically allocate space for a new sllnode.
    sllnode *node;

    node = malloc(sizeof(sllnode));
    // Check to make sure we didn’t run out of memory.
    if (node == NULL)
    {
        printf("Error: memory allocation.\n");
        return NULL;
    }
    // Initialize the node’s val field.
    node->val = val;
    // Initialize the node’s next field.
    node->next = NULL;
    // Return a pointer to the newly created sllnode.
    return node;
}

bool find(sllnode *head, int val)
{
    // Create a traversal pointer point to the list’s head. (we don’t want to change the head).
    sllnode *current = head;
    // If the current node’s val field is what we’re looking for, return true.
    while (current != NULL)
    {
        if (current->val == val)
        {
            return true;
        }
        // If not, set the traversal pointer to the next pointer in the list.
        current = current->next;
    }
    // If you’ve reached the end of the list, return false.
    return false;
}

sllnode *insert(sllnode *head, int val)
{
    // Dynamically allocate space for a new sllnode.
    sllnode *new_node;
    new_node = malloc(sizeof(sllnode));
    // Check to make sure we didn’t run out of memory.
    if (new_node == NULL)
    {
        printf("Error: memory allocation.\n");
        return NULL;
    }
    // Populate and insert the node at the beginning of the linked list.
    new_node->val = val;
    new_node->next = head;
    head = new_node;
    // Return a pointer to the new head of the linked list.
    return head;
}

void destroy(sllnode *head)
{
    // If you’ve reached a null pointer, stop.
    if (head == NULL)
        return;
    // Delete the rest of the list.
    destroy(head->next);
    // Free the current node.
    free(head);
}

int main()
{
    sllnode *first;

    first = create(10);
    return 0;
}