/**
 * File              : dynamic_memory.c
 * Author            : Derrick Park
 * Date              : Wed  8 Aug 09:07:05 2018
 * Last Modified Date: Wed  8 Aug 09:07:05 2018
 * Last Modified By  : Derrick Park
 */

#include <stdio.h>
#include <stdlib.h>
/* syntax:  ptr = malloc(byte-size); */
int main()
{
    int num;
    int i;
    int *ptr;

    num = 10;
    // malloc -> (void *)
    ptr = (int *)malloc(num * sizeof(int));
    ptr = (int *)calloc(num, sizeof(int)); // 0, ..., 0
    ptr = realloc(ptr, 20);                // reallocate ptr(10) to 20 bytes
    free(ptr);
    // in java, Person ptr = new Person();
    // in objc, Person *ptr = [[Person alloc] init]; // [Person new];

    if (ptr == NULL)
    {
        printf("Error! memory not allocated.\n");
        exit(0);
    }
    for (i = 0; i < num; i++)
    {
        *(ptr + i) = i;
        // ptr++; // this moves the ptr (ptr = ptr + 1)
    }

    printf("ptr[0] = %d, ptr[5] = %d\n", *ptr, *(ptr + 5));
    free(ptr);
    return 0;
}