let names = ["Bianca", "Suelen", "Minami", "Nagisa", "Juan", "Marla"];

function put_park(name){
    return name + " Park";
}
let parks = names.map(put_park);


for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
}

function printer(name) {
    console.log(name);
}

names.forEach(printer);

