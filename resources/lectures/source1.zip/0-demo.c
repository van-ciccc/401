#include <stdio.h>

int main()
{
  int age;

  age = 21;
  if (age > 20)
  {
    printf("You can drink!\n");
  }
  else if (age > 10 && age < 20)
  {
    printf("You cannot drink beer\n");
  }
  else
  {
    printf("else\n");
  }

  /*
  ** This is a block comment.
  **
  **
  */
  int i;
  for (i = 0; i < 10; i++)
  {
    /* do something */
  }
  int n;
  n = 10;
  while (n > 0)
  {
    n--;
    printf("n is %d\n", n);
  }

  printf("Hello World\n");
  return 0;
}