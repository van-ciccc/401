
double get_double(char *prompt, double min, double max);