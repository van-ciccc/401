 void swap(int *a, int *b);

 int main() 
 {
 	int a = 10;
 	int b = 12;
 	swap(&a, &b);
 	 
 	return 0;
 }
 void swap(int *a, int *b)
 {
 	int temp = *a;
 	*a = *b;
 	*b = temp;
 }